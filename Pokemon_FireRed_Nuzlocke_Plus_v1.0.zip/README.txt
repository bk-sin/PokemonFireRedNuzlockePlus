Pokemon FireRed Nuzlocke Plus v1.0
Apply "Pokemon FireRed Nuzlocke Plus.bps" to an unmodified Pokemon FireRed (USA) v1.0 ROM
(SHA1 41cb23d8dccc8ebd7c649cd8fbb58eeace6e2fdc, CRC32 DD88761C) with Floating IPS (Flips) or Rom Patcher JS.
Patched result: SHA1 cc019b4f2f1b5d0de228f1c676819c00992d1f2a (32 MB). Save type: Flash 128K.
Strategy set data adapted from Pokexperto (pokexperto.net, CC BY-NC-SA 3.0) and Smogon (via data.pkmn.cc).
